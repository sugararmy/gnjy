import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-intro-three',
  templateUrl: './intro-three.component.html',
  styleUrls: ['./intro-three.component.scss']
})
export class IntroThreeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
